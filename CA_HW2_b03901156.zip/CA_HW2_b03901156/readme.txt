how to program:
1. Input the number of integer you want to sort
2. Input all the required integers
3. The program will sort the input array and output the result